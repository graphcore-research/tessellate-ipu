# Copyright (c) 2022 Graphcore Ltd. All rights reserved.
from ._version import __version__
