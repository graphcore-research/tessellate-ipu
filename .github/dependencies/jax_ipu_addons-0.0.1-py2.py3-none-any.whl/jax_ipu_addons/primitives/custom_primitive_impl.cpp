// cppimport
// NOTE: comment necessary for automatic JIT compilation of the module!
// Copyright (c) 2022 Graphcore Ltd. All rights reserved.
#include "ipu_custom_primitive.hpp"

PYBIND11_MODULE(custom_primitive_impl, m) {
  // Primitive metadata bindings.
  using PrimitiveMetadata = jax::ipu::PrimitiveMetadata;
  namespace py = pybind11;
  py::class_<PrimitiveMetadata>(m, "PrimitiveMetadata")
      .def(py::init<>())
      .def_readwrite("num_inputs", &PrimitiveMetadata::num_inputs)
      .def_readwrite("is_elementwise", &PrimitiveMetadata::is_elementwise)
      .def_readwrite("is_stateless", &PrimitiveMetadata::is_stateless)
      .def_readwrite("is_hashable", &PrimitiveMetadata::is_hashable)
      .def_readwrite("input_to_output_tensor_aliasing",
                     &PrimitiveMetadata::input_to_output_tensor_aliasing)
      .def_readwrite("allocating_indices",
                     &PrimitiveMetadata::allocating_indices)
      .def_readwrite("replica_identical_output_indices",
                     &PrimitiveMetadata::replica_identical_output_indices);
}

// cppimport configuration for compiling the pybind11 module.
// clang-format off
/*
<%
cfg['extra_compile_args'] = ['-std=c++17', '-fPIC', '-O2', '-Wall']
cfg['libraries'] = ['poplar', 'poputil', 'poprand']
cfg['include_dirs'] = []
setup_pybind11(cfg)
%>
*/
