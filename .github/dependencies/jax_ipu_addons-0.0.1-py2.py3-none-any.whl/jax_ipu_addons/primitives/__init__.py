# Copyright (c) 2022 Graphcore Ltd. All rights reserved.
from .custom_primitive_utils import PrimitiveMetadata

from jax_ipu_addons.utils import cppimport_append_include_dirs
import os.path
# Update default `cppimport` library dirs to include `jax_ipu_addons/primitives`.
cppimport_append_include_dirs([os.path.dirname(__file__)])
