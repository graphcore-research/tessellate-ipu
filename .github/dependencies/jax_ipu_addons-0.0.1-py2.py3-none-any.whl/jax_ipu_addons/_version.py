# Copyright (c) 2022 Graphcore Ltd. All rights reserved.
__version__ = "0.0.1"
