# Copyright (c) 2022 Graphcore Ltd. All rights reserved.
from typing import Dict

import numpy as np
import jax.core

from jax.lib import xla_extension
from jax.interpreters import xla

# Numpy dtypes -> XLA primitive types
# Copied from upstream JAX https://github.com/google/jax/blob/main/jax/interpreters/xla.py#L187
# Can be removed once IPU JAX upgraded to upstream JAX.
_dtype_to_primitive_type: Dict[np.dtype, xla_extension.PrimitiveType] = {
    np.dtype('bool'): xla_extension.PrimitiveType.PRED,
    np.dtype('int8'): xla_extension.PrimitiveType.S8,
    np.dtype('int16'): xla_extension.PrimitiveType.S16,
    np.dtype('int32'): xla_extension.PrimitiveType.S32,
    np.dtype('int64'): xla_extension.PrimitiveType.S64,
    np.dtype('uint8'): xla_extension.PrimitiveType.U8,
    np.dtype('uint16'): xla_extension.PrimitiveType.U16,
    np.dtype('uint32'): xla_extension.PrimitiveType.U32,
    np.dtype('uint64'): xla_extension.PrimitiveType.U64,
    np.dtype('float16'): xla_extension.PrimitiveType.F16,
    np.dtype('float32'): xla_extension.PrimitiveType.F32,
    np.dtype('float64'): xla_extension.PrimitiveType.F64,
    np.dtype('complex64'): xla_extension.PrimitiveType.C64,
    np.dtype('complex128'): xla_extension.PrimitiveType.C128,
}
# np.dtype(dtypes.bfloat16): xla_extension.PrimitiveType.BF16,


def dtype_to_primitive_type(dtype: np.dtype) -> xla_extension.PrimitiveType:
  """Converts a NumPy dtype into an XLA PrimitiveType.

  TODO: remove once JAX upgraded to latest.
  """
  # Many things (e.g., strings, scalar types) can be compared with NumPy dtypes,
  # but may not hash correctly. Make sure we have a true np.dtype.
  assert isinstance(dtype, np.dtype), type(dtype)
  try:
    return _dtype_to_primitive_type[dtype]
  except KeyError as err:
    raise TypeError(f"No XLA lowering for NumPy dtype: {dtype}") from err


# Numpy -> TF datatype enum.
# Hardcoded list to avoid bringing TensorFlow as a dependency for JAX.
# For some reason, this TF enum seems to be different from XLA primitive types?
_dtype_to_tf_datatype_enum = {
    np.dtype('bool'): 10,
    np.dtype('int8'): 6,
    np.dtype('int16'): 5,
    np.dtype('int32'): 3,
    np.dtype('int64'): 9,
    np.dtype('uint8'): 4,
    np.dtype('uint16'): 17,
    np.dtype('uint32'): 22,
    np.dtype('uint64'): 23,
    np.dtype('float16'): 19,
    np.dtype('float32'): 1,
    np.dtype('float64'): 2,
    np.dtype('complex64'): 8,
    np.dtype('complex128'): 18,
}


def dtype_to_tf_datatype_enum(dtype: np.dtype) -> int:
  """Convert a Numpy dtype to TensorFlow dtype enum.
  """
  assert isinstance(dtype, np.dtype), type(dtype)
  try:
    return _dtype_to_tf_datatype_enum[dtype]
  except KeyError as err:
    raise TypeError(
        f"No TF datatype enum lowering for NumPy dtype: {dtype}"
    ) from err


def xla_shape_to_aval(xla_shape: xla_extension.Shape) -> jax.core.ShapedArray:
  """Convert an XLA shape into a JAX shaped array.
  """
  assert xla_shape.is_array()
  return jax.core.ShapedArray(xla_shape.dimensions(), xla_shape.numpy_dtype())


def aval_to_xla_shape(aval: jax.core.ShapedArray) -> xla_extension.Shape:
  """Convert a JAX shaped array into an XLA shape.
  """
  return xla.aval_to_xla_shapes(aval)[0]
