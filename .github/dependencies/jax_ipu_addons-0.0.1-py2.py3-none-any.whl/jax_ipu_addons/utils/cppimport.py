# Copyright (c) 2022 Graphcore Ltd. All rights reserved.
from typing import List
import os.path

import cppimport
import cppimport.build_module
import cppimport.importer

from .patching import patch_function


def cppimport_append_include_dirs(include_dirs: List[str]):
  """Append C++ include directories to the default cppimport configuration.

  Args:
    include_dirs: List of additional include directories.
  """
  include_dirs = [os.path.abspath(v) for v in include_dirs]

  # A bit patching of the cppimport building function...
  @patch_function(
      cppimport.build_module.build_module,
      [cppimport.build_module, cppimport.importer]
  )
  def build_module(orig_fn, module_data):
    cfg = module_data["cfg"]
    cfg["include_dirs"] = cfg.get("include_dirs", []) + include_dirs
    return orig_fn(module_data)
